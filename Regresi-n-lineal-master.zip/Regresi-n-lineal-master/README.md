# Regresi-n-lineal
Método numérico
